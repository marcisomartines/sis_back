<?php
/***************************************************************/
/*Sistema de auxilio ao backup - Suporte Gerencial Informatica */
/*Autor: Marciso Gonzalez Martines                             */
/*e-mail: marciso.gonzalez@gmail.com                           */
/***************************************************************/
##cabeçalho padrão
require_once"header.php";
include_once "db.php";
if(!isset($_POST['form_login'])){
    if(!isset($_SESSION['nome'])){
    #    $_SESSION['errors']="Você não esta logado!";
        header("Location: /sis_back/form_login.php");
    }
}else{
    $nome=$_POST['nome'];
    $password=$_POST['password'];
 
    $query="SELECT nome FROM users WHERE nome='$nome' and password=MD5('$password')";
    $result=mysql_query($query) or
        die("Erro na query: $query".mysql_error());
    if(mysql_num_rows($result)==1){//logado com sucesso
        $reg=mysql_fetch_assoc($result);
        $_SESSION['nome']=$reg['nome'];
		$usuario2=$_SESSION['nome'];
		//verificando o tipo do usuario que esta logando no sistema
		$query2="SELECT tipo FROM users WHERE nome='$usuario2'";
		$result2= mysql_query($query2,$cnx) or
			die("Erro na query: $query2".myssql_error());
		$users=mysql_fetch_assoc($result2);
		$tipo=$users['tipo'];
		if($tipo!='l')
			header("Location: /sis_back/tarefa.php");
		else
			header("Location: /sis_back/listar.php");
    }else{//falha no login
        $_SESSION['errors']="Login/senha invalidos";
        header("Location:/sis_back/form_login.php");
    }
}
?>
