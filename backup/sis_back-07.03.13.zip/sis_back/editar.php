<?php
/***************************************************************/
/*Sistema de auxilio ao backup - Suporte Gerencial Informatica */
/*Autor: Marciso Gonzalez Martines                             */
/*e-mail: marciso.gonzalez@gmail.com                           */
/*Formulario para a edição das informações do clientes e       */
/*atribui-lo, quando gerente, a um determinado tecnico         */
/***************************************************************/
//recebendo dados dod Lista
$listar = $_GET['listar']; //recebendo variavel listar que esta vindo da pagina tarefa.php adionado: Danilo 27/02/13

##cabeçlho padrao
require_once "header.php";
#pagina protegida
require_once "login.php";
#conexao com o banco de dados
include_once "db.php";
//verifica se foi passado um codigo para o clientes
if(isset($_GET['codigo']) and !empty($_GET['codigo'])){
    $id=$_GET['codigo'];
#query com informações do clientes    
$query="SELECT id,codigo,nome,tecnico,senha,backup,prazo,finalizado,observacao FROM clientes WHERE codigo='$id'";
$usuario=$_SESSION['nome'];//recebe o nome de que esta logado
$query2="SELECT tipo FROM users WHERE nome='$usuario'";//determina se o usuario é administrador ou comum
#resultado com informações do cliente
$result=  mysql_query($query,$cnx) or
        die("Erro na query: $query".myssql_error());
#resultado com informação do usuario
$result2= mysql_query($query2,$cnx) or
        die("Erro na query: $query2".myssql_error());

$clientes=mysql_fetch_assoc($result);
$users=mysql_fetch_assoc($result2);
$tipo=$users['tipo'];//recebe 'a' se administrado ou 'c' caso seja usuario comum
#informações do cliente
$id=$clientes['id'];
$codigo=$clientes['codigo'];
$nome=$clientes['nome'];
$tecnico=$clientes['tecnico'];
$senha=$clientes['senha'];
$backup=$clientes['backup'];
$prazo=$clientes['prazo'];
$finalizado=$clientes['finalizado'];
$observacao=$clientes['observacao'];
}
else{
    die("CODIGO não econtrada");
}
if(isset($finalizado))
    $finalizado='sim';
else
    $finalizado='nao';

##titulo
echo "<h3>Editar Cliente</h3>";

##formulario de edição
if($tipo=='a'){//se for o gerente mostra essa parte
?>
<!--chamade de script para o calendario para definir a data-->
<link type="text/css" rel="stylesheet" href="calendar/calendar.css?random=20051112" media="screen"></LINK>
<SCRIPT type="text/javascript" src="calendar/calendar.js?random=20060118"></script>
<!--Fim da chamada de script responsavel pelo calendario-->
<form method="post" action="processa_formulario.php">
	<input type="hidden" name="listar"  value="<?php echo $listar ?>"> <!--adicionado variavel listar para passa para pagina processa_formulario.php adicionado: Danilo 27/02/13-->
    <input type="hidden" name="teste" id="teste" value="sim">
    <input type="hidden" name="id" id="id" value="<?=$codigo?>">
    
    <label for="codigo"> C&oacute;digo</label>
    <input type="text" value="<?=$codigo?>" readonly>

    <label for="nome">Empresa</label>
    <input type="text" value="<?=$nome?>" readonly>
    
    <label for="tecnico">Tecnico: </label>
    <select name="tecnico">
        <option value="<?=$tecnico?>"><?=$tecnico?></option>
        <option value=""> </option>
        <option value="Cabrera">Cabrera</option>
        <option value="Danilo">Danilo</option>
        <option value="Fernando">Fernando</option>
        <option value="Joaquim">Joaquim</option>
        <option value="Leandro">Leandro</option>
        <option value="Macedo">Macedo</option>
        <option value="Marcelo">Marcelo</option>
        <option value="Marciso">Marciso</option>
    </select>
    
    <label for="senha">Senha banco de dados: </label>
    <input type="text" name="senha" id="senha" value="<?=$senha?>">
    
    <label for="backup">Backup configurado: </label>
    <select name="backup">
        <option value="<?=$backup?>"><?=$backup?></option>
        <option value="Nao">Não</option>
        <option value="Sim">Sim</option>
    </select>
    
    <label for="prazo">Prazo para finalizar: </label>
    <input type="text" value="<?=$prazo?>" readonly name="prazo">
    <input type="button" value="Data" onclick="displayCalendar(document.forms[0].prazo,'dd-mm-yyyy',this)">
    <!--<input type="text" name="prazo" id="prazo" value="<?=$prazo?>">dd/mm/aaaa-->
    
    <label for="observacao">Observações: </label>
    <!--<input type="text" name="observacao" id="observacao" value="<?=$observacao?>">-->
    <textarea rows="3" name="observacao" id="observacao" value="<?=$observacao?>"><?=$observacao?></textarea>
    <div class="control-group">
        <div class="controls">
            <button type="submit" class="btn btn-success" data-loading-text="Salvando...">Salvar</button>
        </div>
    </div>
</form>
<?php
}else{//se for usuario comum mostra essa parte do codigo
?>
<form method="post" action="processa_formulario.php">
	<input type="hidden" name="listar"  value="<?php echo $listar ?>"><!--adicionado variavel listar para passar para pagina processa_formulario.php adicionado: Danilo 27/02/13-->
    <input type="hidden" name="teste" id="teste" value="nao">
    <input type="hidden" name="id" id="id" value="<?=$codigo?>">
    <input type="hidden" name="finalizado" value="<?=$finalizado?>">

    <label for="codigo"> C&oacute;digo</label>
    <input type="text" class="input-small" value="<?=$codigo?>" readonly>

    <label for="nome">Empresa</label>
    <input type="text" value="<?=$nome?>" readonly>
    
    <label for="senha">Senha banco de dados: </label>
    <input type="text" name="senha" id="senha" value="<?=$senha?>">
    
    <label for="backup">Backup configurado: </label>
    <select name="backup">
        <option value="<?=$backup?>"><?=$backup?></option>
        <option value="Nao">Não</option>
        <option value="Sim">Sim</option>
    </select>
    
    <label for="observacao">Observações: </label>
    <textarea rows="3" name="observacao" id="observacao" value="<?=$observacao?>"><?=$observacao?></textarea>
    <div class="control-group">
        <div class="controls">
            <button type="submit" class="btn btn-success">Salvar</button>
        </div>
    </div>
</form>
<?php
}//fecha o else que executa o formulario para usuario comum
?>
<?php
##rodape padrão
require_once "footer.php";
?>