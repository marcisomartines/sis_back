<?php
/***************************************************************/
/*Sistema de auxilio ao backup - Suporte Gerencial Informatica */
/*Autor: Marciso Gonzalez Martines                             */
/*e-mail: marciso.gonzalez@gmail.com                           */
/***************************************************************/

##Cabeçalho padrão
require_once ("header.php");
//require_once ("usuario.php");
##Pagina Protegida

require_once "login.php";
include_once 'db.php';

$id = $_GET['id'];

$sql = "UPDATE users SET st='i' WHERE id='$id' ";
echo $sql;
if(mysql_query($sql,$cnx) or die (mysql_error() )){ // INICIO IF

		echo '<script language="javascript" type="text/javascript">';
		echo 'window.alert("Usuário desativado com Sucesso!");';  
		echo 'window.history.go(-2);';
		echo '</script>'; 

} //FIM DO IF

else{
	
		echo '<script language="javascript" type="text/javascript">';
		echo 'window.alert("Erro na atualização!");';  
		echo 'window.history.go(-2);';
		echo '</script>'; 
		
	
}


?>