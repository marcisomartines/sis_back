<?php
/****************************************************************/
/*Sistema de auxilio ao backup - Suporte Gerencial Informatica  */
/*Autor: Marciso Gonzalez Martines                              */
/*e-mail: marciso.gonzalez@gmail.com 						    */
/*Script responsavel por processar o cadastro de um novo cliente*/
/****************************************************************/