<?php
/***************************************************************/
/*Sistema de auxilio ao backup - Suporte Gerencial Informatica */
/*Autor: Marciso Gonzalez Martines                             */
/*e-mail: marciso.gonzalez@gmail.com                           */
/***************************************************************/
##cabeçalho padrão
require_once 'header.php';

require_once 'login.php';
?>
<div class="hero-unit">
    <h2>Observa&ccedil;&otilde;es</h2>
    <p>-Cada t&eacute;cnico s&oacute; pode editar clientes atribuidos a ele pelo gerente.</p>
    <p>-N&atilde;o tem como recuperar uma senha, ela &eacute; armazenada criptografada no banco de dados.</p>
</div>
<?php
##rodapé padrão
//require_once 'footer.php';
?>