<hr>
<a href="javascript:history.back();" class="btn btn-success">voltar</a>
</div>
<script src="bootstrap/jquery-latest.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
</hr>